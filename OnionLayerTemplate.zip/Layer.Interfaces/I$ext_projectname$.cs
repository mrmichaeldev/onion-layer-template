﻿using System;

namespace $ext_projectname$.Interfaces
{
    using Models;

    public interface I$ext_projectname$
    {
    }
}
