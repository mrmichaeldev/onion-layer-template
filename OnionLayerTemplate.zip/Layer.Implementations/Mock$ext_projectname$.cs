using System;

namespace $ext_projectname$.Implementations
{
    using Interfaces;
    using Models;

    public class Mock$ext_projectname$ : I$ext_projectname$
    {
    }
}
