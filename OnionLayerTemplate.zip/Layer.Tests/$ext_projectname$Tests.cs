﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $ext_projectname$.Tests
{
    using Interfaces;
    using Models;

    [TestClass]
    public class $ext_projectname$Tests
    {
        I$ext_projectname$ _$ext_projectname$;

        [TestInitialize]
        public void Initialize()
        {
            _$ext_projectname$ = new $ext_projectname$();
        }

        [TestMethod]
        public void TestMethod1()
        {
            
        }
    }
}
