﻿using System;

namespace $ext_projectname$.Models
{
    public class $ext_projectname$Model
    {
    }
}
